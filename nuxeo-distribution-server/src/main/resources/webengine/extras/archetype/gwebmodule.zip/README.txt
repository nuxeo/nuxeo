
This is a generated project using Nuxeo Archetypes. 
This project is a Nuxeo WebEngine Groovy module.

The plugin provides:

* Project structure compatible with Nuxeo WebEngine
* An Ant target for deployment into a WebEngine server running on a JBoss.
* An example of ModuleEntry object and of using object views

